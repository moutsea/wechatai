export const PARTIAL_FAILURE_NOTICE = "提示：处理过程中有部分步骤报错，请留意结果是否完整。";
export class AgentReply {
    options;
    chunks = [];
    sawError = false;
    deliveryFailed = false;
    constructor(options = {}){
        this.options = options;
    }
    accept(payload, kind) {
        if (payload.isError) {
            this.sawError = true;
            return;
        }
        if (kind !== "final" || payload.isReasoning || payload.isFallbackNotice || payload.isCompactionNotice || payload.isStatusNotice && !this.options.command) return;
        if (payload.text?.trim()) this.chunks.push(payload.text);
        if (payload.mediaUrl || payload.mediaUrls?.length) this.chunks.push("此渠道暂不支持附件，请在 OpenClaw 查看生成的文件。");
    }
    failDelivery() {
        this.deliveryFailed = true;
    }
    finish(alreadySent) {
        if (this.deliveryFailed) throw new Error("Agent reply delivery failed");
        if (this.chunks.length) {
            const text = this.chunks.join("\n\n");
            return this.sawError ? `${text}\n\n${PARTIAL_FAILURE_NOTICE}` : text;
        }
        if (this.sawError) throw new Error("Agent dispatch failed");
        return alreadySent ? null : "";
    }
}
