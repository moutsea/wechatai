import { DatabaseSync } from "node:sqlite";
import { mkdirSync, chmodSync } from "node:fs";
import { dirname } from "node:path";
import { createHash, randomUUID } from "node:crypto";
export class RelayError extends Error {
    status;
    constructor(status){
        super(`Wechatai relay returned HTTP ${status}`), this.status = status;
    }
}
export async function relay(account, action, body, signal) {
    const url = new URL(account.endpoint);
    if (url.protocol !== "https:" && !(url.protocol === "http:" && [
        "localhost",
        "127.0.0.1",
        "[::1]"
    ].includes(url.hostname))) throw new Error("Use HTTPS, or loopback HTTP for local development");
    if (url.username || url.password || url.search || url.hash || url.pathname !== "/") throw new Error("endpoint must be an origin");
    const response = await fetch(new URL(`/api/openclaw/${action}`, url), {
        method: "POST",
        redirect: "error",
        headers: {
            authorization: `Bearer ${account.token}`,
            "content-type": "application/json"
        },
        body: JSON.stringify(body),
        signal: signal ? AbortSignal.any([
            signal,
            AbortSignal.timeout(20000)
        ]) : AbortSignal.timeout(20000)
    });
    if (!response.ok) {
        await response.body?.cancel();
        throw new RelayError(response.status);
    }
    return await response.json();
}
export const accountFingerprint = (a)=>createHash("sha256").update(`${a.endpoint}\0${a.token}`).digest("hex");
export class Journal {
    db;
    queuedListeners = new Set();
    runnerId;
    constructor(path){
        mkdirSync(dirname(path), {
            recursive: true,
            mode: 0o700
        });
        this.db = new DatabaseSync(path);
        chmodSync(path, 0o600);
        this.db.exec(`PRAGMA journal_mode=WAL;
      CREATE TABLE IF NOT EXISTS settings (id TEXT PRIMARY KEY, value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, state TEXT NOT NULL, routeId TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS routes (id TEXT PRIMARY KEY);
      CREATE TABLE IF NOT EXISTS outbox (id TEXT PRIMARY KEY, data TEXT NOT NULL, state TEXT NOT NULL, createdAt INTEGER NOT NULL);`);
        this.db.prepare("INSERT OR IGNORE INTO settings VALUES ('runnerId', ?)").run(randomUUID());
        this.runnerId = this.db.prepare("SELECT value FROM settings WHERE id = 'runnerId'").get().value;
    }
    state(id) {
        return this.db.prepare("SELECT state FROM jobs WHERE id = ?").get(id)?.state;
    }
    start(job) {
        this.db.prepare("INSERT OR IGNORE INTO jobs VALUES (?, 'running', ?)").run(job.id, job.routeId);
        this.db.prepare("INSERT OR IGNORE INTO routes VALUES (?)").run(job.routeId);
    }
    hasRoute(id) {
        return Boolean(this.db.prepare("SELECT id FROM routes WHERE id = ?").get(id));
    }
    queue(event) {
        if (event.jobId) event = {
            ...event,
            runnerId: this.runnerId
        };
        this.db.exec("BEGIN IMMEDIATE");
        try {
            this.db.prepare("INSERT OR IGNORE INTO outbox VALUES (?,?,'pending',?)").run(event.eventId, JSON.stringify(event), Date.now());
            if (event.jobId) this.db.prepare("UPDATE jobs SET state = 'finished' WHERE id = ?").run(event.jobId);
            this.db.exec("COMMIT");
        } catch (e) {
            this.db.exec("ROLLBACK");
            throw e;
        }
        for (const listener of this.queuedListeners)listener();
        return event.eventId;
    }
    onQueued(listener) {
        this.queuedListeners.add(listener);
        return ()=>this.queuedListeners.delete(listener);
    }
    push(routeId, text) {
        if (!this.hasRoute(routeId)) throw new Error("Unknown Wechatai destination; start a conversation from WeChat first");
        if (!text.trim() || text.length > 30000) throw new Error("Wechatai text must contain 1–30000 characters");
        return this.queue({
            eventId: randomUUID(),
            routeId,
            text,
            status: "completed"
        });
    }
    pending() {
        return this.db.prepare("SELECT data FROM outbox WHERE state = 'pending' ORDER BY createdAt LIMIT 20").all().map((r)=>JSON.parse(r.data));
    }
    settle(id, state) {
        this.db.prepare("UPDATE outbox SET state = ?, data = '{}' WHERE id = ?").run(state, id);
    }
    close() {
        this.db.close();
    }
}
const flushing = new WeakMap();
export function flush(journal, account, signal) {
    const active = flushing.get(journal);
    if (active) return active.then(()=>flush(journal, account, signal));
    const task = (async ()=>{
        for(let batch = journal.pending(); batch.length; batch = journal.pending()){
            for (const event of batch){
                try {
                    await relay(account, "event", event, signal);
                    journal.settle(event.eventId, "sent");
                } catch (e) {
                    if (e instanceof RelayError && [
                        400,
                        402,
                        403,
                        409,
                        413,
                        422
                    ].includes(e.status)) journal.settle(event.eventId, "rejected");
                    else throw e;
                }
            }
        }
    })().finally(()=>flushing.delete(journal));
    flushing.set(journal, task);
    return task;
}
export async function executeJob(job, journal, account, execute, signal) {
    const state = journal.state(job.id);
    if (state === "finished") return;
    if (state === "running" || job.state === "claimed") {
        journal.start(job);
        if (job.state === "pending") {
            const claim = await relay(account, "claim", {
                id: job.id,
                runnerId: journal.runnerId
            }, signal);
            if (!claim.claimed) return;
        }
        journal.queue({
            eventId: randomUUID(),
            routeId: job.routeId,
            jobId: job.id,
            text: "",
            status: "failed"
        });
        return;
    }
    journal.start(job);
    const result = await relay(account, "claim", {
        id: job.id,
        runnerId: journal.runnerId
    }, signal);
    if (!result.claimed) return;
    let text = "", status = "completed";
    try {
        const result = await execute();
        text = result ?? "";
        if (result !== null && !text.trim()) status = "failed";
    } catch  {
        status = "failed";
    }
    journal.queue({
        eventId: randomUUID(),
        routeId: job.routeId,
        jobId: job.id,
        text: text.length > 30000 ? text.slice(0, 29950) + "\n\n[内容较长，剩余部分请在 OpenClaw 查看]" : text,
        status
    });
}
